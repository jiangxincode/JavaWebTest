# Environment and deploy file
# For use with bin/server_deploy, bin/server_package etc.
DEPLOY_HOSTS=""

APP_USER=
APP_GROUP=
INSTALL_DIR=
LOG_DIR=
SPARK_HOME=/data/software/crazyjvm/spark
# Only needed for Mesos deploys
#SPARK_EXECUTOR_URI=/home/spark/spark-0.8.0.tar.gz
